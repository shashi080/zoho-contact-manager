## TO RUN APPLICATION 

### TO RUN BACKEND 
-  ``` cd backend ```
- ``` npm install ```
- ``` npm start ```


### TO RUN FRONTEND
-  ``` cd frontend ```
- ``` npm install ```
- ``` ng serve ```