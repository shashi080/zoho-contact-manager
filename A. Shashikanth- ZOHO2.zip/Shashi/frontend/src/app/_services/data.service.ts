import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


const AUTH_API = 'http://localhost:8080/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class DataService {



  constructor(private http: HttpClient) { }
  
  get(): Observable<any> {
    return this.http.get<any>(AUTH_API)
  }

  login(email: string, password: string): Observable<any> {
    return this.http.post(AUTH_API + 'login', {
      email,
      password
    }, httpOptions);
  }

  signup(email: string, password: string,secret:string): Observable<any> {
    return this.http.post(AUTH_API + 'signup', {
      email,
      password,
      secret
    }, httpOptions);
  }

  getAll():Observable<any>  {
    const user_id = JSON.parse(window.localStorage.getItem('user_id') || '{}');
    return this.http.post(AUTH_API + 'getAll', {
      user_id,
    }, httpOptions);
  }

  addContact(name: string, email: string, phone: string): Observable<any> {
  
    const user_id = JSON.parse(window.localStorage.getItem('user_id') || '{}');
    
    
    return this.http.post(AUTH_API + 'addContact', {
      user_id,
      name,
      email,
      phone,
    }, httpOptions);
  }

  public getUser(): any {
    const user = window.localStorage.getItem('user');
    if (user) {
      
      return JSON.parse(user);
    }

    return false;
  }

  

  public logout(): any{
    return window.localStorage.clear();
  }



}
