import { NonNullAssert } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { DataService } from './_services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'frontend';
  
  isLoggedIn?= false;

  userEmail?: string;
  
  contacts?: any = [];

  form: any = {
    email: null,
    password: null
  };

  Signupform: any = {
    email: null,
    password: null,
    secret:null,
  };



  contactForm: any = {
    name: null,
    email: null,
    phone:null
  }



  constructor(private dataService: DataService) { }
  
  ngOnInit(): void {
    console.log(this.isLoggedIn);
    if (this.dataService.getUser()) {
      this.isLoggedIn = true;
      console.log(this.isLoggedIn);
    }
    this.getAll();
    if (this.isLoggedIn) {
      this.getAllContacts();
      
    }

  }

  onLoginSubmit(): void{
    const { email, password } = this.form;

    this.dataService.login(email, password).subscribe(
      data => {
        console.log(data);
        window.localStorage.setItem('user', JSON.stringify(data));
        window.localStorage.setItem('user_id', JSON.stringify(data.id));
        this.isLoggedIn = true;
       
        window.location.reload()
       
      }
    )
  }

  onSignupSubmit(): void{
    const { email, password,secret } = this.Signupform;

    this.dataService.signup(email, password,secret).subscribe(
      data => {
        console.log(data);
        window.location.reload();
       
      }
    )
  }

  //get all contacts
  getAllContacts(): void{
    this.dataService.getAll().subscribe(
      data => {
        this.contacts = data.contacts;
        console.log(data.contacts);
      }
    )
    
  }

  //save contact
  onContactSubmit(): void{
    const { name, email, phone } = this.contactForm;

    this.dataService.addContact(name,email,phone).subscribe(
      data => {
        console.log(data);
        window.location.reload();
      }
    )
  }

  onLogout(): void{
    console.log("hemmlo")
    this.dataService.logout();
    this.isLoggedIn = false;
  }

  

  getAll(): void{
    this.dataService.get().subscribe((res) => {
      console.log(res.message);
    });
  }
}
